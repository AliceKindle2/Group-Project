package PCSearch;

import java.util.List;

public class PCSearch {

    private PCDBM database;
    private Msg msg;  // Message object for handling output

    public PCSearch() {
        this.database = new PCDBM();
        this.msg = new Msg();
    }

    public SearchResult search(String query) {
        if (!database.isValidPartName(query)) {
            msg.clearMessage();
            msg.addMessage("Error: Invalid part name.");
            return new SearchResult(msg.getMessage());
        }

        List<PCPart> results = database.searchParts(query);
        msg.clearMessage();

        if (results.isEmpty()) {
            msg.addMessage("Error: No matching parts found.");
            return new SearchResult(msg.getMessage());
        }

        msg.addMessage("Search results:");
        for (PCPart part : results) {
            msg.addMessage(part.toString());
        }
        return new SearchResult(msg.getMessage());
    }

    public void printSearchResults(SearchResult result) {
        result.printResults();
    }
}
