package PCSearch;

public class PCPart {

    private String type;
    private String brand;
    private String name;
    private double price;

    public PCPart() {
        this("Unknown", "Unknown", "Unknown", 0.0);
    }

    public PCPart(String type, String brand, String name, double price) {
        this.type = type;
        this.brand = brand;
        this.name = name;
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public String getBrand() {
        return brand;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public boolean isValid() {
        return name.length() >= 3 && name.length() <= 40 && name.matches("[a-zA-Z0-9\\- ]+");
    }

    @Override
    public String toString() {
        return String.format("%s %s %s ($%.2f)", type, brand, name, price);
    }
}
