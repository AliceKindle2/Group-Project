package PCSearch;

public class SearchResult {
    private String message;

    public SearchResult(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void printResults() {
        System.out.println(message);
    }
}
