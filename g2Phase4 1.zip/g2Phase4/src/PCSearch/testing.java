package PCSearch;

public class testing {
    public static void main(String[] args) {
        PCSearch search = new PCSearch();

        System.out.println("Test Case 1: Valid Search");
        search.printSearchResults(search.search("cpu"));

        System.out.println("\nTest Case 1.a: Valid Long Search");
        search.printSearchResults(search.search("B550"));

        System.out.println("\nTest Case 2: Invalid Search (too short)");
        search.printSearchResults(search.search("cp"));

        System.out.println("\nTest Case 2.a: Invalid Search (not in DB)");
        search.printSearchResults(search.search("xpu"));

        System.out.println("\nTest Case 3: Exceptional Case (empty string)");
        search.printSearchResults(search.search(""));

        System.out.println("\nTest Case 3.a: Exceptional Case (too long)");
        search.printSearchResults(search.search("A".repeat(100)));

        System.out.println("\nTest Case 3.b: Exceptional Case (special characters)");
        search.printSearchResults(search.search("Desktop 9000 8000 & 7000 ATX Motherboard"));
    }
}
