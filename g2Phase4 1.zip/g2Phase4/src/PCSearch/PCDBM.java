package PCSearch;

import java.util.ArrayList;
import java.util.List;

public class PCDBM {

    private List<PCPart> parts;

    public PCDBM() {
        parts = new ArrayList<>();
        loadParts();
    }

    //temp
    private void loadParts() {
        parts.add(new PCPart("CPU", "Intel", "Core i7-12700K", 399.99));
        parts.add(new PCPart("Motherboard", "ASUS", "ROG Strix B550-F", 199.99));
        parts.add(new PCPart("GPU", "NVIDIA", "RTX 3080", 699.99));
    }

    public boolean isValidPartName(String partName) {
        return partName.length() >= 3 && partName.length() <= 40 && partName.matches("[a-zA-Z0-9\\- ]+");
    }

    public List<PCPart> searchParts(String keyword) {
        List<PCPart> result = new ArrayList<>();
        if (keyword == null || keyword.isEmpty()) {
            return result;
        }

        Double priceKeyword = null;
        try {
            priceKeyword = Double.parseDouble(keyword);
        } catch (NumberFormatException e) {}

        for (PCPart part : parts) {
            boolean matches = part.getType().toLowerCase().contains(keyword.toLowerCase()) ||
                    part.getName().toLowerCase().contains(keyword.toLowerCase()) ||
                    part.getBrand().toLowerCase().contains(keyword.toLowerCase());

            if (priceKeyword != null && part.getPrice() == priceKeyword) {
                matches = true;
            }

            if (matches) {
                result.add(part);
            }
        }

        return result;
    }
}
