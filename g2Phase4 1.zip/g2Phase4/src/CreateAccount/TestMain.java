package CreateAccount;

import java.util.Scanner;


//testing
public class TestMain {
    public static void main(String[] args) {
        AccountDB database = new AccountDB();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Create Account\n2. Login\n3. Exit");
            System.out.print("Choose an option: ");

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
                continue;
            }

            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                CreateAccount accountCreator = new CreateAccount(database);

                System.out.print("Enter a username: ");
                String username = scanner.nextLine();
                while (!accountCreator.setUsername(username)) {
                    System.out.print("Enter a valid username: ");
                    username = scanner.nextLine();
                }

                System.out.print("Enter an email: ");
                String email = scanner.nextLine();
                while (!accountCreator.setEmail(email)) {
                    System.out.print("Enter a valid email: ");
                    email = scanner.nextLine();
                }

                System.out.print("Enter a password: ");
                String password = scanner.nextLine();
                while (!accountCreator.setPassword(password)) {
                    System.out.print("Enter a valid password: ");
                    password = scanner.nextLine();
                }

                if (accountCreator.createAccount()) {
                    System.out.println("Account successfully created!");
                } else {
                    System.out.println("Failed to create account.");
                }
            }
            else if (choice == 2) {
                System.out.print("Enter your username: ");
                String loginUsername = scanner.nextLine();

                System.out.print("Enter your password: ");
                String loginPassword = scanner.nextLine();

                if (database.verifyAccount(loginUsername, loginPassword)) {
                    System.out.println("Login successful! Welcome, " + loginUsername + "!");
                } else {
                    System.out.println("Login failed! Invalid username or password.");
                }
            }
            else if (choice == 3) {
                System.out.println("Exiting...");
                break;
            }
            else {
                System.out.println("Invalid choice. Try again.");
            }
        }

        scanner.close();
    }
}
