package CreateAccount;

import Login.User;
import java.util.regex.Pattern;

public class CreateAccount {
    private String username;
    private String email;
    private String password;
    private AccountDB accountDB;

    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9]{8,20}$");
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z]{2,}$");
    private static final Pattern PASSWORD_PATTERN = Pattern.compile("^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@#$%^&+=!])[A-Za-z\\d@#$%^&+=!]{8,12}$");

    public CreateAccount(AccountDB accountDB) {
        this.accountDB = accountDB;
    }

    public boolean setUsername(String name) {
        if (name == null || !USERNAME_PATTERN.matcher(name).matches()) {
            System.out.println("Error: Username must be 8-20 alphanumeric characters (no spaces or special characters).");
            return false;
        }
        this.username = name;
        return true;
    }

    public boolean setEmail(String email) {
        if (email == null || !EMAIL_PATTERN.matcher(email).matches()) {
            System.out.println("Error: Invalid email format.");
            return false;
        }
        this.email = email;
        return true;
    }

    public boolean setPassword(String password) {
        if (password == null || !PASSWORD_PATTERN.matcher(password).matches()) {
            System.out.println("Error: Password must be 8-12 characters long, contain at least one letter, one number, and one special character.");
            return false;
        }
        this.password = password;
        return true;
    }

    public boolean createAccount() {
        if (username == null || email == null || password == null) {
            System.out.println("Error: Missing account details.");
            return false;
        }

        User user = new User(username, email, password);
        return accountDB.addAccount(user);
    }
}
