package CreateAccount;

import Login.User;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class AccountDB {
    private static final String FILE_NAME = "accounts.txt";
    private Map<String, User> accounts;

    public AccountDB() {
        accounts = new HashMap<>();
        loadAccounts();
    }

    public boolean addAccount(User user) {
        if (accounts.containsKey(user.getUsername())) {
            System.out.println("Error: Username already exists!");
            return false;
        }
        accounts.put(user.getUsername(), user);
        saveAccounts();
        return true;
    }

    public boolean verifyAccount(String username, String password) {
        User user = accounts.get(username);
        return user != null && user.checkPassword(password);
    }

    private void saveAccounts() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (User user : accounts.values()) {
                writer.write(user.getUsername() + "," + user.getEmail() + "," + user.getPassword());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving accounts: " + e.getMessage());
        }
    }

    private void loadAccounts() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    accounts.put(parts[0], new User(parts[0], parts[2], parts[1])); // Ensure correct order
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading accounts: " + e.getMessage());
        }
    }
}
