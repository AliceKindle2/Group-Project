package CreateAccount;

public class Msg {
    private StringBuilder message = new StringBuilder();

    public void add() {
        message.append("New message\n");
    }

    public void print() {
        System.out.println(message.toString());
    }

    public void addMessage(String msg) {
        message.append(msg).append("\n");
    }

    public void clearMessage() {
        message.setLength(0);
    }

    public String getMessage() {
        return message.toString();
    }
}
