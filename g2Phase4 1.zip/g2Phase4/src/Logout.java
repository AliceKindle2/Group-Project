public class Logout
{
	public boolean isLoggedOut;
	
	public Logout()
 	{
		this.isLoggedOut = false;
	}
	
	public boolean getLogout()
	{
		this.isLoggedOut = true;
		return true;
	}
	
	public void print()
	{
		if (isLoggedOut)
		{
			System.out.println("Logout successful!");
		}
		else
		{
			System.out.println("Still logged in.");
		}
	}
	
	public void clearSesssion()
	{
		System.out.println("Cleared user session.");
	}
}
