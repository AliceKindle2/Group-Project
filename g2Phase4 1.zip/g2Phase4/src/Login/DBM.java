package Login;

import java.util.ArrayList;
import java.util.List;

public class DBM {
	private List<User> users = new ArrayList<>();

	public boolean contains(User user) {
		return users.contains(user);
	}

	public User getUser(int index) {
		if (index >= 0 && index < users.size()) {
			return users.get(index);
		}
		return null;
	}

	public void addUser(User user) {
		users.add(user);
	}

	public int getUserCount() {
		return users.size();
	}
}
