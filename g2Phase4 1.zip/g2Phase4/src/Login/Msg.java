package Login; // Ensure this matches your directory structure

public class Msg {
	private StringBuilder message = new StringBuilder();

	public void add() {
		message.append("New message\n");
	}

	public void print() {
		System.out.println(message.toString());
	}

	public void addMessage(String msg) { // Renamed parameter to "msg"
		message.append(msg).append("\n");
	}

	public void clearMessage() {
		message.setLength(0);
	}
}
